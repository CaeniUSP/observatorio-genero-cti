<template>
  <section class="container  bg-white py-16 px-6 text-gray-800">
    <div class="container  max-w-5xl mx-auto">
      <h2 style="color: #333f42;" class="container  text-3xl font-semibold mb-8">Publicações</h2>
      <div class="container  grid grid-cols-3 gap-6">
        <div class="container  border p-4 rounded shadow">[Publicação 1]</div>
        <div class="container  border p-4 rounded shadow">[Publicação 2]</div>
        <div class="container  border p-4 rounded shadow">[Publicação 3]</div>
      </div>
    </div>
  </section>
</template>