<script setup>
import Logo from '../assets/logo.png'
</script>
<template>
  <section class="container  min-vh-100 d-flex align-items-center bg-gray-100 flex flex-col justify-center items-center text-center p-6">
    <img :src="Logo" alt="Logo Observatório Paulista de Gênero" class="container  w-64 mx-auto" />
    <p class="container  mt-4 fs-6 text-gray-600">Promovendo equidade e transparência na construção do futuro</p>
    <button class="container  mt-6 btn btn-success  px-6 py-3 rounded  transition">
      Saiba mais
    </button>
  </section>
</template>