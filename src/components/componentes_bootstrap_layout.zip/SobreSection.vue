<template>
  <section class="container  container px-4 px-5 py-16 text-gray-800">
    <div class="container  max-w-3xl container mx-auto">
      <h2 class="container  text-3xl font-semibold mb-6">Sobre Nós</h2>
      <p class="container  mb-4 text-justify">
        Somos um grupo de pesquisa dedicado à promoção da igualdade de gênero na ciência, tecnologia e inovação (CT&I), sob a liderança da Profa. <strong>Janina Onuki</strong>. Nosso trabalho está inserido no âmbito do projeto <strong>GENDER STI</strong> – <em>Gender Equality in Science, Technology and Innovation Bilateral and Multilateral Dialogues</em> –, uma iniciativa internacional que reúne <strong>18 instituições de 16 países</strong> em <strong>4 continentes</strong>.
      </p>
      <p class="container  mb-4 text-justify">
        O projeto GENDER STI tem como missão identificar desigualdades de gênero nas colaborações internacionais em CT&I e propor soluções colaborativas e sustentáveis para enfrentá-las. Aprovado no âmbito do <strong>programa Horizon 2020 da Comissão Europeia</strong>, o projeto visa não apenas o diagnóstico, mas também o desenvolvimento de estratégias efetivas para ampliar a equidade de gênero nos diálogos bilaterais e multilaterais entre países.
      </p>
      <p class = "text-justify">
        Como legado, o projeto prevê a criação de dois observatórios de gênero em CT&I: o <strong>Observatório Paulista de Gênero em CT&I</strong>, na América Latina, e o <strong>Observatório Europeu de Gênero em CT&I</strong>, na Europa. Ambos atuarão em sinergia para garantir a continuidade do monitoramento, análise e formulação de políticas públicas voltadas à igualdade de gênero, consolidando-se como referências internacionais na área mesmo após o encerramento do projeto.
      </p>
    </div>
  </section>

</template>