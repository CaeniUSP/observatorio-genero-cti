<template>
  <section class="container  bg-white py-16 px-6">
    <div class="container  max-w-md max-w-lg mx-auto">
      <h2 style="color: #333f42;" class="container  text-3xl font-semibold mb-6 text-center text-gray-800">Contato</h2>
      <form class="container  grid gap-4">
        <input class="container  border p-3 rounded" placeholder="Nome" />
        <input class="container  border p-3 rounded" placeholder="Email" />
        <textarea class="container  border p-3 rounded" rows="4" placeholder="Mensagem"></textarea>
        <button class="container  bg-green-600  py-2 rounded hover:btn btn-success">Enviar</button>
      </form>
    </div>
  </section>
</template>