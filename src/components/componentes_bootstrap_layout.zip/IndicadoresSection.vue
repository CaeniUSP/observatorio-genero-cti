<template>
  <section class="container  bg-gray-50 py-16 px-6">
    <div class="container  max-w-6xl mx-auto">
      <h2 style="color: #333f42;" class="container  text-3xl font-semibold mb-8 text-gray-800">Dados e Indicadores</h2>
      <div class="container  row row-cols-1 row-cols-sm-2 gap-8">
        <div class="container  bg-white shadow-md rounded p-4">[Gráfico 1]</div>
        <div class="container  bg-white shadow-md rounded p-4">[Gráfico 2]</div>
      </div>
      <div class="container  mt-6">
        <button class="container  bg-green-600  px-4 py-2 rounded hover:btn btn-success">Baixar todos os dados</button>
      </div>
    </div>
  </section>
</template>