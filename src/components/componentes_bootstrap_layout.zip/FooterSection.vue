<template>
  <footer class="container  bg-gray-800  text-center text-sm text-base py-6">
    <p>&copy; 2025 Observatório Paulista de Gênero em CT&I. Todos os direitos reservados.</p>
  </footer>
</template>